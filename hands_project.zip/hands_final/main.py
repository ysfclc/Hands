
from core.orchestrator import Orchestrator
if __name__ == "__main__":
    print("HANDS OS v2 Light Speed Ready")
