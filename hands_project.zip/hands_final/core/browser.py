class Browser: pass
