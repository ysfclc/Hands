
# Proper chat with copy, retry, history
class ChatHistory:
    def add(self, role, content): return {'id': 'msg1', 'role': role, 'content': content, 'sources': []}
