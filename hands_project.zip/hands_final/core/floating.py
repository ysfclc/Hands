
# Floating bubble outside app
class FloatingIcon:
    def enable(self): return {'enabled': True, 'permission': 'SYSTEM_ALERT_WINDOW', 'quick_actions': ['Quick Chat','Voice Note','Scan Screen']}
