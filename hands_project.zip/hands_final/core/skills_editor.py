
# Editable skills dropdown not JSON
class SkillsEditor:
    def list(self): return [{'id': 'send_message', 'category': 'App Automation', 'editable': True, 'source': 'app_schemas/linkedin.json'}]
