
# Maps mobile apps like browser - AccessibilityService DOM
class AppMapper:
    def map_app(self, package, dump):
        return {'package': package, 'elements': dump, 'skills': ['search_in_app','send_message'], 'reusable': True}
