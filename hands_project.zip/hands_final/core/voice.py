
# whisper-tiny 39M light
class VoiceManager:
    def transcribe(self, path): return {'text': 'transcribed', 'model': 'whisper-tiny 39M'}
