
class MobileOptimizer:
    def check(self, model):
        # RAM check, reject if cannot run
        required = model.get('ram_required_gb', 2.5)
        avail = 2.1
        if avail < required:
            return {'can_run': False, 'reason': f'REJECTED: Needs {required}GB, you have {avail}GB. Try qwen2.5:0.5b 0.4GB', 'action': 'reject'}
        return {'can_run': True, 'best_quant': 'Q4_K_M', 'optimizations': ['mmap','Q4_K_M','lazy','flash']}
