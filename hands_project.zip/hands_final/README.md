# HANDS OS v2 Light Speed
Light, alive, RAM-aware, app mapper, floating bubble
